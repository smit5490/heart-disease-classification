
from setuptools import setup

setup(
    name='heart_disease_classification',
    version='0.1',
    scripts=['predictor.py', 'preprocess.py'])
